//global variables: window.colsNeed, window.keywords, window.numColumns, 
numColumns = 6;

let p1 = ['Richard', 'Phoenix', 18, 70, 10000, 'UCBerkeley'];
let p2 = ['John', 'Mesa', 25, 65, 100000, 'ASU'];
let p3 = ['Karl', 'Phoenix', 80, 74, 0, 'UofA'];
let p4 = ['James', 'Scottsdale', 55, 66, 200000, 'Emory'];
let p5 = ['Zack', 'LosAngeles', 18, 70, 10000, 'UofA'];
let p6 = ['Olivia', 'Seattle', 35, 63, 60000, 'UCLA'];
let p7 = ['Jamie', 'Houston', 24, 64, 75000, 'UTAustin'];
let p8 = ['Zack', 'Phoenix', 30, 76, 40000, 'ASU'];
let p9 = ['Mia', 'New York', 55, 62, 200000, 'NYU'];
let p10 = ['Avery', 'SanDiego', 70, 65, 0, 'Penn'];
let p11 = ['Grace', 'Houston', 25, 68, 60000, 'UofA'];
let p12 = ['Riley', 'Phoenix', 18, 72, 5000, 'NAU'];
let p13 = ['Hannah', 'Los Angeles', 26, 66, 40000, 'UCLA'];
let p14 = ['Liam', 'Chicago', 35, 70, 100000, 'Emory'];
let p15 = ['Alex', 'Dallas', 48, 76, 75000, 'UTAustin'];
let p16 = ['Daniel', 'SanFrancisco', 22, 70, 120000, 'UCBerkeley'];
let p17 = ['Matt', 'Philadelphia', 60, 68, 0, 'Penn'];
let p18 = ['Brooke', 'Scottsdale', 18, 65, 8000, 'UofA'];

let dataComplete = [p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p14, p15, p16, p17, p18];

$(addToPage());

function navBar(){
	$('#mySidenav').empty();
	$('#mySidenav').append('<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>');
	$('#mySidenav').append('<label>What do you want to see</label>');
	$('#mySidenav').append('<label class = "checkBox"><input type="checkbox" id="firstName" checked>Name</label><br>');
	$('#mySidenav').append('<label class = "checkBox"><input type="checkbox" id="city" >City</label><br>');
	$('#mySidenav').append('<label class = "checkBox"><input type="checkbox" id="age" checked>Age</label><br>');
	$('#mySidenav').append('<label class = "checkBox"><input type="checkbox" id="height">Height</label><br>');
	$('#mySidenav').append('<label class = "checkBox"><input type="checkbox" id="income">Income</label><br>');
	//$('#mySidenav').append('<label class = "checkBox"><input type="checkbox" id="location">Location</label><br>');
	$('#mySidenav').append('<label class = "checkBox"><input type="checkbox" id="education">Education</label><br>');
	//$('#mySidenav').append('<label class = "checkBox"><input type="checkbox" id="maritalStatus">Marital Status</label><br>');
	$('#mySidenav').append('<input type="button" id="innerSubmit" value="Submit" onclick="submitBtn()">');
}

function addToPage(){
	$('body').append('<div id="mySidenav" class="sidenav">');
	for (let i=0; i<dataComplete.length; i++) {
		$('#allData').append(Array(dataComplete[i]));
		$('#allData').append('<br>');
	}
	navBar();
}

function openNav() {
	document.getElementById("mySidenav").style.width = "250px";
	document.getElementById('main').style.marginLeft = '250px';
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById('main').style.marginLeft = "0";
}

function submitBtn() {
	var val1 = document.getElementById('firstName').checked;
	var val2 = document.getElementById('city').checked;
	var val3 = document.getElementById('age').checked;
	var val4 = document.getElementById('height').checked;
	var val5 = document.getElementById('income').checked;
	var val6 = document.getElementById('education').checked;
	window.colsNeed = [val1, val2, val3, val4, val5, val6];
	closeNav();
}

function searchAction() {
	var inp = document.getElementById('search').value;
	window.keywords = kwParser(String(inp));
	window.preliminaryData = prelimData(window.numColumns, window.keywords, dataComplete);
	window.finalData = finData(window.preliminaryData, window.colsNeed, window.numColumns);

	for (let i=0; i<finalData.length; i++) {
		$('#searchData').append(Array(finalData[i]));
		$('#searchData').append('<br>');
	}
}




function kwParser(kw) {
	let keys = kw.split(',');
	return keys;
}
function kwSearcher(kw, arr) {
	for (var key in kw) {
		for (var item in arr) {
			if (item == key) {
				return true;
			}
		}
	}
	return false;
}
function prelimData(numCols, keywords, data) {
	let ret = [];
	for (d of data) {
		if (kwSearcher(keywords, d)) {
			ret.push(d);
		}
	}
	alert(ret)
	return ret;
}
function finData(prelim, colsNeeded, numCols) {
	let final = [];
	while(prelim.length > 0) {
		let temp = [];
		for (let i=0; i<numCols; i++) {
			if (colsNeeded[i] === true) {
				temp.push(prelim.shift());
			} else {
				prelim.shift()
			}
		}
		final.push(temp);
	}
	return final;
}